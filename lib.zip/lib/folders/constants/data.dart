const currency = "₹";
